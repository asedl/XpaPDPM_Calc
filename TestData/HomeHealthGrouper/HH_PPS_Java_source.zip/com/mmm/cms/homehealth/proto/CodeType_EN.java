/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mmm.cms.homehealth.proto;

/**
 * Identifies a code type instead of using an integer
 *
 * @author 3M Health Information Systems  for CMS Home Health
 */
public enum CodeType_EN {

    ICD_9,
    ICD_10;
}
